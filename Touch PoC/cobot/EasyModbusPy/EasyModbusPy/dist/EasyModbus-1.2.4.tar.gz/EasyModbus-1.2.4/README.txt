EasyModbusTCP - THE standard library for Modbus RTU and Modbus TCP

Python 2.7
Python 3.6

Requirements: pyserial (only for Modbus RTU)

Visit www.EayModbusTCP.net for more informations and Codesamples